/* ═══════════════════════════════════════════════════════════════
   MK MALIK — REAL SERVER (v1)
   ═══════════════════════════════════════════════════════════════
   এই একটাই ফাইল তোমার অ্যাপের "মস্তিষ্ক":
     1️⃣  নিজস্ব PeerJS ব্রোকার  (/peerjs)  — ফ্রি পাবলিক ক্লাউডের উপরে আর নির্ভর নয়,
         রুম/ভয়েস/চ্যাটের সংযোগ এখন তোমার সার্ভার দিয়েই মেলে
     2️⃣  ছোট্ট ইউজার-ডেটাবেস (db.json) — রেজিস্ট্রেশন + হার্টবিট + অ্যাডমিন তালিকা
     3️⃣  হেলথ-চেক (/health) — UptimeRobot দিয়ে জাগিয়ে রাখার জন্য

   চালানো:   npm install   &&   node server.js
   Environment:
     PORT        — সার্ভারের পোর্ট (Render নিজে দিয়ে দেয়)
     ADMIN_KEY   — প্যানেলের গোপন চাবি (ডিফল্ট mkmalik#2026, বদলে নিও!)
   ═══════════════════════════════════════════════════════════════ */
'use strict';
const express=require('express');
const {ExpressPeerServer}=require('peer');
const fs=require('fs');

const app=express();
app.use(express.json({limit:'512kb'}));

/* ── CORS: পাবলিক ব্রোকার — যেকোনো জায়গা থেকে সংযোগ ── */
app.use((req,res,next)=>{
  res.set('Access-Control-Allow-Origin','*');
  res.set('Access-Control-Allow-Headers','*, x-admin-key');
  res.set('Access-Control-Allow-Methods','GET,POST,DELETE,OPTIONS');
  if(req.method==='OPTIONS')return res.sendStatus(204);
  next();
});

/* ── ছোট্ট JSON ডেটাবেস (ফাইলে জমা থাকে) ── */
const DBF=process.env.DB_PATH||'./db.json';
let db={users:{}};
try{db=Object.assign(db,JSON.parse(fs.readFileSync(DBF,'utf8')));}catch(e){}
let _st=null;
function save(){clearTimeout(_st);_st=setTimeout(()=>{try{fs.writeFileSync(DBF,JSON.stringify(db));}catch(e){}},800);}

const AKEY=process.env.ADMIN_KEY||'mkmalik#2026';
const START=Date.now();
const adminOK=req=>req.headers['x-admin-key']===AKEY;

/* ── হোম পেজ: সার্ভার বেঁচে আছে দেখতে ── */
app.get('/',(req,res)=>{
  const up=((Date.now()-START)/1000)|0;
  res.set('Content-Type','text/html; charset=utf-8');
  res.send('<meta name="viewport" content="width=device-width,initial-scale=1">'
   +'<body style="font-family:sans-serif;background:#12081f;color:#fff;text-align:center;padding:40px 16px">'
   +'<div style="font-size:56px">👑</div><h1 style="color:#ffd76e;margin:6px 0">MK MALIK SERVER</h1>'
   +'<p>✅ বেঁচে আছি — '+up+' সেকেন্ড ধরে দৌড়াচ্ছি</p>'
   +'<p>🔌 PeerJS ব্রোকার: <code style="background:#241a42;padding:4px 10px;border-radius:8px">/peerjs</code></p>'
   +'<p>👥 নিবন্ধিত ইউজার: <b style="color:#ffd76e">'+Object.keys(db.users).length+'</b></p>'
   +'<p style="color:#8a7fb0;font-size:12px">v1 · pure Node.js · real-time ready</p></body>');
});

/* ── UptimeRobot ঘুম-ভাঙানোর জন্য ── */
app.get('/health',(req,res)=>res.json({ok:true,up:((Date.now()-START)/1000)|0,users:Object.keys(db.users).length,ts:Date.now()}));

/* ── 📝 রেজিস্ট্রেশন / প্রোফাইল আপসার্ট ── */
app.post('/api/register',(req,res)=>{
  const b=req.body||{};
  if(!b.uid||!b.name)return res.status(400).json({ok:0,err:'uid + name required'});
  const id=String(b.uid).slice(0,32);
  const old=db.users[id]||{};
  db.users[id]={uid:id,name:String(b.name).slice(0,40),phone:String(b.phone||'').slice(0,20),
   country:String(b.country||'').slice(0,40),vip:+b.vip||0,
   created:old.created||Date.now(),last:Date.now()};
  save();
  res.json({ok:1,user:db.users[id]});
});

/* ── 💓 হার্টবিট (ইউজার অনলাইন আছে জানানো) ── */
app.post('/api/heartbeat',(req,res)=>{
  const b=req.body||{}; if(!b.uid)return res.status(400).json({ok:0});
  const u=db.users[String(b.uid).slice(0,32)];
  if(u){u.last=Date.now();if(b.name)u.name=String(b.name).slice(0,40);save();}
  res.json({ok:1,known:!!u});
});

/* ── 👑 অ্যাডমিন API (ভবিষ্যতের প্যানেল-সিঙ্কের জন্য) ── */
app.get('/api/users',(req,res)=>{
  if(!adminOK(req))return res.status(401).json({ok:0,err:'wrong admin key'});
  res.json({ok:1,users:Object.values(db.users).sort((a,b)=>(b.last||0)-(a.last||0))});
});
app.delete('/api/users/:uid',(req,res)=>{
  if(!adminOK(req))return res.status(401).json({ok:0});
  delete db.users[req.params.uid]; save(); res.json({ok:1});
});

/* ── HTTP সার্ভার + 🔌 নিজস্ব PeerJS ব্রোকার ── */
const PORT=process.env.PORT||3000;
const srv=app.listen(PORT,()=>console.log('🚀 MK MALIK server on :'+PORT));
const peers=ExpressPeerServer(srv,{path:'/'});
let peerCount=0;
peers.on('connection',c=>{peerCount++;console.log('[peer] +',c.id,'('+peerCount+' online)');});
peers.on('disconnect',c=>{peerCount=Math.max(0,peerCount-1);console.log('[peer] -',c.id);});
app.use('/peerjs',peers);
app.get('/api/stats',(req,res)=>res.json({ok:1,peersOnline:peerCount,users:Object.keys(db.users).length,up:((Date.now()-START)/1000)|0}));
console.log('👑 MK MALIK real server ready — broker at /peerjs');
